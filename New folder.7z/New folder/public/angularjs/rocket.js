
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {
	$scope.submit = function(){
	$http({
         method : "POST",
         url : "/backhand",
    	data : {
			"username" : $scope.username,
			"pas" : $scope.pas,
			"aditya" : $scope.aditya,
			"dhiraj" : $scope.dhiraj,
			"saurab" : $scope.saurab
		}
  }).success(function (response) {
	      $scope.myWelcome = response.naam;
  });
	};
	
});