/**
 * http://usejsdoc.org/
 */
exports.backhand = function(req,res,next){
	var a = req.param("username");
	var b = req.param("pas");
	var c = req.param("dhiraj");
	var d = req.param("aditya");
	var e = req.param("saurab");
	var total = 0;
	console.log(a);	console.log(b);	console.log(c);	console.log(d);	console.log(e);//	console.log(a);
	//console.log(a);
	if (a == true){
		
		total = total + 100;	
	}
	
	if (b == true){
		console.log("b")
		total = total + 100;	
	}
	if (c == true){
		total = total + 100;	
	}
	if (d == true){
		total = total + 100;	
	}
	
	if (e == true){
		total = total + 100;	
	}

	var json_responses = { "naam" : total};
	res.send(json_responses);
};