/**
 * http://usejsdoc.org/
 */
function calculate(req,res,next){
	var num1 = parseInt(req.param("no1"));
	var num2 = parseInt(req.param("no2"));
	var op = req.param("oper");
	switch(op){
	case "add":{
		var ans = num1 + num2;
		break;
	}
	case "sub":{
		var ans = num1 - num2;
		break;
	}
	case "mul":{
		var ans = num1 * num2;
		break;
	}
	case "div":{
		if (num2 == 0){
			var ans = "undefined as the divident is zero";
		}else {
		var ans = num1 / num2;
		break;
		}
	}
	}
	res.render('answer',{data:ans});
} 
exports.calculate =calculate;