
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path')
  , session = require('client-sessions');
var home = require('./routes/home]');
var signuoop = require('./routes/signupop');
var app = express();
var home1 = require('./routes/home1');
var myConnection= require("./routes/connection_pooling");
var search = require('./routes/search_#');
var bcrypt = require('bcrypt-nodejs');

// all environments

app.use(session({   
	  
	cookieName: 'session',    
	secret: 'cmpe273_test_string',    
	duration: 30 * 60 * 1000,    //setting the time for active session
	activeDuration: 5 * 60 * 1000,  })); // setting time for the session to be active when the window is open // 5 minutes set currently


app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);
app.get('/signin', home.signin);
app.get('/homepage',home.redirectToHomepage);
app.get('/count_inr',home.count_inr);
app.get('/dispcount',home.dispcount);
app.post('/remove_follower',home.remove_follower);
app.post('/re_tweet',home.re_tweet);
app.get('/search',search.search);
app.post('/dis_following',home1.dis_following);
app.post('/dis_follower',home1.dis_follower);
app.post('/add_follower',home1.add_follower);
app.post('/othersprofile',home1.othersprofile);
app.post('/tweetenter',home.tweetenter);
app.post('/tweetdis',home.tweetdis);
app.post('/logout',home.logout);
app.post('/checklogin', home.checklogin);
app.post('/viewprofile',home.viewprofile);
app.get('/getAllUsers', home.getAllUsers);
app.get('/signupoperation', home.signupoperation);
myConnection.createpool();
http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
