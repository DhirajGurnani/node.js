var home = angular.module('home', []);
home.controller('home', function($scope, $http) {
$scope.submit = function(username) {
	//alert("aaya");
		$http({
			method : "POST",
			url : '/viewprofile',
			data : {
				"inputUsername" : $scope.username
			}
		}).success(function(data) {
			//checking the response data for statusCode
			
			$scope.username = data.username;
			$scope.firstname = data.firstname;
			$scope.lastname = data.lastname;
			$scope.gender = data.gender;
			$scope.dateofbirth = data.dateofbirth;
			$scope.following = data.following;
			$scope.follower = data.follower;
			$scope.check=true;
			});
};
$scope.tweetentr =function(){
	$http({
		method : "POST",
		url : '/tweetenter',
		data:{
			"tweet" : $scope.tweet
		}
	}).success(function(data){
		alert("kaise");
		$scope.recenttweet=data.tweet;
		$scope.count_tweet=data.count_tweet;
		//window.location.assign("/count_inr");
	});
}
});/**
 * http://usejsdoc.org/
 */
home.controller('tweetdis', function($scope,$http,uname){
	$scope.uname = uname;
	$scope.submit = function() {
		alert(uname);
			$http({
				method : "POST",
				url : '/tweetdis',
				data :{
					"username" : $scope.uname
				}
				
			}).success(function(data) {
				//checking the response data for statusCode
				//alert(data);
				$scope.list = data;
				//alert(list);
				
			/*	$scope.username = data.username;
				$scope.firstname = data.firstname;
				$scope.lastname = data.lastname;
				$scope.gender = data.gender;
				$scope.dateofbirth = data.dateofbirth;
				$scope.following = data.following;
				$scope.follower = data.follower;
				$scope.check=true;
			*/
				});
	};	
});

home.controller('follow', function($scope,$http,uname){
	$scope.uname = uname;
	$scope.submit = function(){
		alert(uname);
		$http({
			
			method :"POST",
			url: '/add_follower',
			data:{
				"username" :$scope.uname
				}
		}).success(function(data){
			alert(data);
			$scope.count_followers=data.count;
			});
	};
});

home.controller('dis_following',function($scope,$http,uname){
	$scope.uname = uname;
	$scope.submit = function(){
		alert(uname);
		$http({
			method : "POST",
			url: '/dis_following',
			data:{
				"username":$scope.uname
			}
		}).success(function(data){
			$scope.list = data;
		});
	};
});
home.controller('dis_follower',function($scope,$http,uname){
	$scope.uname = uname;
	$scope.submit = function(){
		alert(uname);
		$http({
			method : "POST",
			url: '/dis_follower',
			data:{
				"username":$scope.uname
			}
		}).success(function(data){
			alert(data);
			$scope.list = data;
		});
	};
});