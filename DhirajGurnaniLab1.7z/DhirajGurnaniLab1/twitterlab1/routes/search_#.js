/**
 * http://usejsdoc.org/
 */
var ejs = require("ejs");
var mysql = require('./mysql');

exports.search=function(req,res){
	console.log("its happening");
	var hash = req.param("hashtag");
	var gethashtag = 'select * from tweets where tweets regexp("#'+hash+'");';
	mysql.fetchData(gethashtag,function(err,results){
		if(err){
			throw err;
		} else {
			res.render('hashsearch',{data:results});
		}
	});
};