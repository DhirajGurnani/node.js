/**
 * http://usejsdoc.org/
 */
var ejs = require("ejs");
var mysql = require('./mysql');

exports.signupoperation = function (req,res,next){
	var uname = req.param("username");
	var pass = req.param("password");
	var fname = req.param("firstname");
	var lname = req.param("lastname");
	var gder = req.param("gender");
	var birthdate = req.param("date");
//	check user already exists
	var getUser='insert into users values(null'+',"'+ req.param("username")+'","'+req.param("password")+'","'+req.param("firstname")+'","'+req.param("lastname")+'","'+req.param("dateofbirth")+'","'+req.param("gender")+'");';
	console.log("Query is:"+getUser);
	mysql.fetchData	(function(err,results){
		if(err){
			throw err;
		}
		else
		{
			console.log(results);
			if(results.length > 0){
				console.log("valid Login");
				ejs.renderFile('./views/sign.ejs', {
					data: results } , function(err, result) {
//						render on success
						if (!err) {
							res.end(result);
						}
//						render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					});
			}
			else {
				console.log("Invalid Login");
				ejs.renderFile('./views/signuplogin.ejs',function(err, result) {
//					render on success
					if (!err) {
						res.end(result);
					}
//					render or error
					else {
						res.end('An error occurred');
						console.log(err);
					}
				});
			}
		}
	},getUser);
}
