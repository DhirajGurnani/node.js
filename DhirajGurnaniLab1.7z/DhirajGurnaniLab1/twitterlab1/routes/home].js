/**
 * http://usejsdoc.org/
 */
var bcrypt = require('bcrypt-nodejs');
var ejs = require("ejs");
var mysql = require('./mysql');
function signin(req,res) {
	ejs.renderFile('./views/signin.ejs',function(err, result) {
//		render on success]
		if(results[0])[]{
				bycrypt.compare(password,results[0].loginpassword, function(err,correct){
					id(correctPassword){
						req.session.username=username;
						josn_response={"statuscode":200};
						res.send(josn_response);
					}
				});
		}
		if (!err) {
			
			res.end(result);
		}
//		render or error
		else {
			res.end('An error occurred');
			console.log(err);
		}
	});
}

exports.tweetdis = function(req,res,next){
	//var usernam = req.session.username;
	console.log("tweet");
	var etUser='select * from tweets where username ="'+req.param("username")+'";';
	console.log("Query is:"+etUser);
	mysql.fetchData	(etUser,function(err,results){
		if(err){
			throw err;
		}
		else
		{
			console.log(results);
			if(results.length > 0){
				console.log("valid Login");
				/*var data = [];
				for(var i in results){
				 data[i] = results[i].tweets;
				}*/
				res.send(results);
				/*ejs.renderFile('./views/tweet.ejs', {
					data: results } , function(err, result) {*/
//						render on success
						/*if (!err) {

							res.end(result);
						}
//						render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
*/					//});
			}
			/*
			else {
				console.log("Invalid Login");
				ejs.renderFile('./views/notweet.ejs',function(err, result) {
//					render on success
					if (!err) {
						res.end(result);
					}
//					render or error
					else {
						res.end('An error occurred');
						console.log(err);
					}
				});			}*/
		
		}
	});
}
exports.signupoperation = function (req,res,next){
	var uname = req.param("inputUsername");
	var pass = req.param("inputPassword");
	var fname = req.param("firstname");
	var lname = req.param("lastname");
	var gder = req.param("gender");
	var birthdate = req.param("date");
//	check user already exists
   var cryptedpass = bcrypt.hashSync(password);
 
	var etUser='insert into users values(null'+',"'+ req.param("inputUsername")+'","'+req.param("inputPassword")+'","'+req.param("firstname")+'","'+req.param("lastname")+'","'+req.param("dateofbirth")+'","'+req.param("gender")+'",0,0,0);';
	console.log("Query is:"+etUser);
	mysql.fetchData	(etUser,function(err,results){
		if(err){
			throw err;
		}
		else
		{
			console.log(results);
			if(results.length > 0){
				console.log("valid Login");
				ejs.renderFile('./views/sign.ejs', {
					data: results } , function(err, result) {
//						render on success
						if (!err) {

							res.end(result);
						}
//						render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					});
			}
			else {
				console.log("Invalid Login");
				ejs.renderFile('./views/signuplogin.ejs',function(err, result) {
//					render on success
					if (!err) {
						res.end(result);
					}
//					render or error
					else {
						res.end('An error occurred');
						console.log(err);
					}
				});			}
		}
	});
}

exports.checklogin = function(req,res)
{
	var username, password;
	username = req.param("username");
	password = req.param("password");

	var json_responses;

	if(username!== ''  && password!== '')
	{
		console.log(username+" "+password);

//		check user already exists
		var getUser="select * from users where username='"+req.param("username")+"' and password='" +req.param("password") +"'";
		console.log("Query is:"+getUser);
		mysql.fetchData	(getUser,function(err,results){
			if(err){
				throw err;
			}
			else
			{
				console.log(results);
				if(results.length > 0){
					/*	console.log("valid Login");
				ejs.renderFile('./views/successLogin.ejs', {
					data: results } , function(err, result) {
//						render on success
						if (!err) {
							res.end(result);
						}
//						render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					});
					 */
					console.log("I want to have sex");
					req.session.username = req.param("username");
					console.log("Session initialized");
					json_responses = {"statusCode" : 200  };
					res.send(json_responses);

				}else{
					json_responses = {"statusCode" : 401};
					res.send(json_responses);
				}
				/*else {
				console.log("Invalid Login");
				ejs.renderFile('./views/failLogin.ejs',function(err, result) {
//					render on success
					if (!err) {
						res.end(result);
					}
//					render or error
					else {
						res.end('An error occurred');
						console.log(err);
					}
				});
			}*/
			}
		});
	}

	else
	{
		json_responses = {"statusCode" : 401};
		res.send(json_responses);
	}
};

exports.remove_follower = function(req,res){
	console.log('adding follower');
	var count1, count2;
	var username = req.param("username");
	var getfollower = "insert into following values(null,'"+req.session.username+"','"+username+"');";
	console.log("Query is:" + getfollower);
	mysql.fetchData (getfollower,function(err,results){
		if(err){
			throw err;
		} else{
			console.log(results);
			//if(results.length > 0){
				console.log("added follower");
				//res.send(username);
				console.log("why is it jumping");
				var getcount1 = 'select * from users where username ="'+req.session.username+ '";';
				mysql.fetchData(getcount1,function(err,results1){
					if (err){
						throw err;
					} else {
						for (var i in results1){
							var count1 = results1[i].following;
						}
							count1 = count1 - 1;
						var putcount1 = "update users set following = '" + count1 + "' where username = '"+req.session.username+"';";
						mysql.fetchData(putcount1,function(err,results2){
							if (err){
								console.log("check1");
								throw err;
							} else {
								var getcount2 = "select * from users where username ='"+username+"';";
								mysql.fetchData(getcount2,function(err,results3){
									if(err){
										throw err;
									} else {
										for (var i in results3){
											var count2 = results3[i].followers;
										}
										count2 = parseInt(count2) -1;
										var putcount2 = "update users set followers = '"+count2+"' where username = '"+username+"';";
										mysql.fetchData(putcount2,function(err,results4){
											if (err){
												throw err;
											} else {
												var response = {"count":count2};
												console.log(count2);
												res.send(response);
											}
										});						
									}
								});
							}
						});
					}
				});
			//}
				
		}
	});

};
//Redirects to the homepage
exports.redirectToHomepage = function(req,res)
{
//	Checks before redirecting whether the session is valid
	if(req.session.username)
	{
		//Set these headers to notify the browser not to maintain any cache for the page being loaded
		res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
		res.render("homepage",{username:req.session.username});
	}
	else
	{
		res.redirect('/');
	}
};



//Logout the user - invalidate the session
exports.logout = function(req,res)
{
	console.log("Logout");
	req.session.destroy();
	res.redirect('/signin');
};

exports.viewprofile=function(req,res)
{
//	check user already exists
	var inputUsername = req.param("username");
	var tuser;
	if (inputUsername == undefined){
		var tUser="select * from users where username='"+req.session.username+"'";

	} else {
		var tUser="select * from users where username='"+req.param("inputUsername")+"'";
	}
	console.log("Query is:"+tUser);
	mysql.fetchData	(tUser,function(err,results){
		if(err){
			throw err;
		}
		else
		{
			console.log(results);
			if(results.length > 0){
				/*	var uname,fname,lname,dob,sex,fing,fer;
				 for(var i in results){
					 uname = results[i].username;
					 fname = results[i].firstname;
					 lname = results[i].lastname;
					 dob = results[i].dateofbirth;
					 sex = results[i].gender;
					 fing = results[i].following;
					 fer = results[i].followers;
				 }
					 var json_responses = { "username" : uname ,"firstname" : fname,"lastname" : lname,"dateofbirth" : dob,"gender" : sex,"following" : fing,"follower" : fer };
				res.send(json_responses);
				 */

				console.log("valid Login");
				ejs.renderFile('./views/othersprofile.ejs', {
					data: results } , function(err, result) {
//						render on success
						if (!err) {
							res.end(result);
						}
//						render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					});
			}
			else {
				console.log("Invalid Login");
				ejs.renderFile('./views/failLogin.ejs',function(err, result) {
//					render on success
					if (!err) {
						res.end(result);
					}
//					render or error
					else {
						res.end('An error occurred');
						console.log(err);
					}
				});
			}
		}
	});

}
exports.re_tweet =function(req,res,tweet){
	console.log("increment operation");
	var tewt = tweet;
	console.log(tewt);
var getUser='select * from users where username="'+req.session.username+'";';
	console.log("Query is:"+getUser);
	//res.render('index');
	mysql.fetchData	(getUser,function(err,results1){
		if(err){
			throw err;
		}
		else
		{
			if(results1.length > 0){
				 for(var i in results1){
					 var uname = results1[i].tweet;
					 uname = uname + 1;
					 console.log(uname);
					 
					 res.redirect('/dispcount',{data:uname});
						//var tUser='update users SET tweet ="uname" WHERE username="'+req.session.username+'";';
				 }
			console.log(results1);
			/*if(err){
				throw err;
			} else { 
			/s/	res.send(tweet);
			}*/
			}
		}
	});

};

exports.tweetenter = function(req,res){
	var tweet = req.param("tweet");
	if (tweet.length > 0 ){
	var tUser='insert into tweets values(null,"'+req.session.username+'","'+tweet+'");';//  
	console.log("Query is:"+tUser);
	mysql.fetchData	(tUser,function(err,results){
		if(err){
			throw err;
		}
		else
		{
			var user ='select * from users where username ="'+req.session.username+ '";';
			//res.send(tweet);
			mysql.fetchData (user,function(err,results2){
				if(err){
					throw err;
				} else{
					console.log("increment mein aaya");
					console.log(results2);
					console.log(results2.tweet);
					for(var i in results2){
					var uname = results2[i].tweet;
					}
					console.log(uname);
					uname = parseInt(uname) + 1;
					console.log(uname);
					var inrcount = 'update users set tweet ="'+uname+'" where username ="'+req.session.username+'";';
					mysql.fetchData (inrcount,function(errr,result3){
						if(err){
							throw err;
						} else {
							console.log(result3);
							var response ={"tweet" : tweet,"count_tweet" : uname};
							res.send(response);
						
						}
					});
				}
			});
			//console.log("redirecting");
		/*	
			console.log(results);
			var temp_tweet = results.tweet;
			temp_tweet = temp_tweet + 1;
			var gettuser='update users set tweet='+temp_tweet+' where username ="'+req.session.username+'"; select * from users where username ="'+req.session.username+'";';
			console.log("Query is:"+getuser);
			mysql.fetchData(function(err,result){
				if (err){
					throw err;
				} else{
					res.send(result);
				}
			},gettuser);
			if(err){
				throw err;
			}
		*/
		}
	});
	}
};
	/*console.log("increment operation");
	var tewt = tweet;
	console.log(tewt);
var getUser='select * from users where username="'+req.session.username+'";';
	console.log("Query is:"+getUser);
	//res.render('index');
	var uname=0;
	mysql.fetchData	(function(err,results1){
		if(err){
			throw err;
		}
		else
		{
			//if(results1.length > 0){
					 uname = results1.tweet;
					 uname = uname + 1;
					 console.log(uname);
					 
//					 res.redirect('/dispcount',{data:uname});
						//var tUser='update users SET tweet ="uname" WHERE username="'+req.session.username+'";';
				// }
			//console.log(results1);
			if(err){
				throw err;
			} else { 
			/s/	res.send(tweet);
			}
			//}
		}
	},getUser);
	console.log("chutiyapa ho raha h");
	res.send(uname);
	*///}
//	res.redirect('/inc_count');
//};

exports.count_inr=function(req,res,tweet){
	console.log("increment operation");
	var tewt = tweet;
	console.log(tewt);
var getUser='select * from users where username="'+req.session.username+'";';
	console.log("Query is:"+getUser);
	//res.render('index');
	mysql.fetchData	(getUser,function(err,results1){
		if(err){
			throw err;
		}
		else
		{
			if(results1.length > 0){
				 for(var i in results1){
					 var uname = results1[i].tweet;
					 uname = uname + 1;
					 console.log(uname);
					 
					 res.redirect('/dispcount',{data:uname});
						//var tUser='update users SET tweet ="uname" WHERE username="'+req.session.username+'";';
				 }
			console.log(results1);
			/*if(err){
				throw err;
			} else { 
			/s/	res.send(tweet);
			}*/
			}
		}
	});

};

exports.dispcount = function(req,res,tweet){
	console.log("going in the display count");
	var uname = tweet;
	var tUser='update users SET tweet ="uname" WHERE username="'+req.session.username+'";';
	console.log("Query is:"+tUser);
	//res.render('index');
	mysql.fetchData	(tUser,function(err,results1){
		if(err){
			throw err;
		}
		else
		{
		//	if(results1.length > 0){
					 res.send(uname);
						//var tUser='update users SET tweet ="uname" WHERE username="'+req.session.username+'";';
				 
			console.log(results1);
			/*if(err){
				throw err;
			} else { 
			/s/	res.send(tweet);
			}*/
			}
		//}
	});
	 
};
			function getAllUsers(req,res)
			{
				var getAllUsers = "select * from users";
				console.log("Query is:"+getAllUsers);
				mysql.fetchData(getAllUsers,function(err,results){
					if(err){
						throw err;
					}
					else
					{
						if(results.length > 0){
							var rows = results;
							var jsonString = JSON.stringify(results);
							var jsonParse = JSON.parse(jsonString);
							console.log("Results Type: "+(typeof results));
							console.log("Result Element Type:"+(typeof
									rows[0].emailid));
							console.log("Results Stringify Type:"+(typeof
									jsonString));
							console.log("Results Parse Type:"+(typeof
									jsString));
							console.log("Results: "+(results));
							console.log("Result Element:"+(rows[0].emailid));
							console.log("Results Stringify:"+(jsonString));
							console.log("Results Parse:"+(jsonParse));
							ejs.renderFile('./views/successLogin.ejs',{data:jsonParse},function(err, result) {
//								render on success
								if (!err) {
									res.end(result);
								}
//								render or error
								else {
									res.end('An error occurred');
									console.log(err);
								}
							});
						}
						else {
							console.log("No users found in database");
							ejs.renderFile('./views/failLogin.ejs',function(err, result) {
//								render on success
								if (!err) {
									res.end(result);
								}
//								render or error
								else {
									res.end('An error occurred');
									console.log(err);
								}
							});
						}
					}
				});
			}
			exports.signin=signin;
			exports.getAllUsers=getAllUsers;