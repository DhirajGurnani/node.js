/**
 * http://usejsdoc.org/
 */

var ejs = require("ejs");
var mysql = require('./mysql');


exports.othersprofile= function(req,res){
	var username = req.param("inputUsername");
	var otheruser= "select* from users where username ='"+username+"';";
//	var etUser='select * from tweets where username ="'+req.param("username")+'";';
	console.log("Query is:"+otheruser);
	mysql.fetchData	(otheruser,function(err,results){
		if(err){
			throw err;
		}
		else
		{
			console.log(results);
			if(results.length > 0){
				console.log("valid Login");
				res.render('samnewalekiprofile',{data:results});

			}
		
		}
	});
};
exports.add_follower=function(req,res){
	console.log('adding follower');
	var count1, count2;
	var username = req.param("username");
	var getfollower = "insert into following values(null,'"+req.session.username+"','"+username+"');";
	console.log("Query is:" + getfollower);
	mysql.fetchData (getfollower,function(err,results){
		if(err){
			throw err;
		} else{
			console.log(results);
			//if(results.length > 0){
				console.log("added follower");
				//res.send(username);
				console.log("why is it jumping");
				var getcount1 = 'select * from users where username ="'+req.session.username+ '";';
				mysql.fetchData(getcount1,function(err,results1){
					if (err){
						throw err;
					} else {
						for (var i in results1){
							var count1 = results1[i].following;
						}
							count1 = count1 + 1;
						var putcount1 = "update users set following = '" + count1 + "' where username = '"+req.session.username+"';";
						mysql.fetchData(putcount1,function(err,results2){
							if (err){
								console.log("check1");
								throw err;
							} else {
								var getcount2 = "select * from users where username ='"+username+"';";
								mysql.fetchData(getcount2,function(err,results3){
									if(err){
										throw err;
									} else {
										for (var i in results3){
											var count2 = results3[i].followers;
										}
										count2 = parseInt(count2) +1;
										var putcount2 = "update users set followers = '"+count2+"' where username = '"+username+"';";
										mysql.fetchData(putcount2,function(err,results4){
											if (err){
												throw err;
											} else {
												var response = {"count":count2};
												console.log(count2);
												res.send(response);
											}
										});						
									}
								});
							}
						});
					}
				});
			//}
				
		}
	});
};

exports.dis_following = function(req,res){
	var username = req.param("username");
	console.log(username);
	var getfollowing = "select * from following where follower_name = '"+username+"';";
	mysql.fetchData (getfollowing,function(err,results){
		if(err){
			throw err;
		} else{
			if (results.length>0){
			console.log(results);
			res.send(results);
			}
			else {
				var result = "following none";
				res.send(result);
			}
		}
	});
};


exports.dis_follower = function(req,res){
	var username = req.param("username");
	console.log(username);
	var getfollower = "select * from following where following_name = '"+username+"';";
	mysql.fetchData (getfollower,function(err,results){
		if(err){
			throw err;
		} else{
			if (results.length>0){
			console.log(results);
			res.send(results);
			} else {
				var resuk ={"id":3, "follower_name" : "follower none"};
				res.send(resuk);
			}
		}
	});
};