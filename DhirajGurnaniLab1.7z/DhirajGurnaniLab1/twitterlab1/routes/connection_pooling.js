/**
 * http://usejsdoc.org/
 */
var mysql = require('./mysql.js');//importing module mysql
var arrayOfConnection= [];

exports.createpool = function(){
for(var i=0;i<100;i++){
	var connection=mysql.getConnection();
	arrayOfConnection.push(connection);
}
};

exports.getConnectionFromPool =function (){
	var connection = arrayOfConnection.pop();
	return connection;
};
exports.releaseConnectionFromPool =function (connection){
	arrayOfConnection.push(connection);
};
